from django.apps import AppConfig


class ShallwegameConfig(AppConfig):
    name = 'shallWeGame'
