from django.urls import path
from . import views

urlpatterns = [
    path('auth/user/', views.get_authenticated_user, name='discord_authenticated'),
    path('login/', views.discord_login, name='discord_login'),
    path('login/redirect/', views.discord_login_redirect, name='discord_login_redirect'),
    path('logout/', views.discord_logout, name='discord_logout'),

    path('post/', views.post_list, name='post'),
    path('post/<int:id>', views.post_info, name='post_info'),
    path('post/<int:id>/like', views.post_like_toggle, name='post_like_toggle'),
    path('comment/', views.comment_list, name='comment'),
    path('comment/<int:id>', views.comment_info, name='comment_info'),
    path('tag/', views.tag_list, name='tag'),
    path('tag/<int:id>/', views.tag_info, name='tag_info'),
    
    # chatroom to be added
]